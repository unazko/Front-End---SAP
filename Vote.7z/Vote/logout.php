<?php

include_once('includes/functions.php');
session_start();

if (session_destroy()) {
    redirect('login.php', "");
}