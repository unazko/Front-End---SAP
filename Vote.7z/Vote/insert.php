<?php

include_once('includes/database.php');
include_once('includes/config.php');
include_once('includes/functions.php');

if ($_SERVER['REMOTE_ADDR'] == "::1") {
    
    $username = "unazko";
    $password = "333123";

    if( ! preg_match('/^[A-Za-z0-9_]{3,64}$/', $username) ) {

        $content = "Special symbols are not allowed, only letters, digits and uderscore. And username must be between 3 and 64 symbols.";
        $type = 'error';

        echo "Bad input.<br>";
        exit;
    }

    if((strlen($password) < 6) OR (strlen($password) > 64)) {

        echo "Bad input.<br>";
        exit;
    }      

    $hash = password_hash($password, PASSWORD_BCRYPT, ["cost" => cost]);

    $dsn = "pgsql:host=" . host . ";dbname=" . db . ";port=" . port;
    $pdo = Database::get_connection($dsn, user, pass);

    $sql = "INSERT INTO users (username, hash) values(?, ?)";
    $stmt = $pdo->prepare($sql)->execute([$username, $hash]); 
    
    echo "User: <b>" . $username . "</b> is created.";
} else {
    
    header("HTTP/1.0 404 Not Found");
    echo "<h1>404 Not Found</h1>";
    echo "The page that you have requested could not be found.";
    exit();
}



