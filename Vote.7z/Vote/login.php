<!DOCTYPE html>
<html>
    <head>
        <title>Регистрация</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link type="text/css" rel="stylesheet" href="css/styles.css">
    </head>

    <body>
        <form class="center" action="login_action.php" method="post">

            <ul style="list-style-type: none">
                <li>Регистрация</li>
                <li>Потребителско име:<input type="text" name="username" style="width: 100px"></li>
                <li>Парола:<input type="password" name="password" style="width: 100px"><input class="font12" type="submit" value="Вход"></li>

            </ul>
        </form>
    </body>

</html>