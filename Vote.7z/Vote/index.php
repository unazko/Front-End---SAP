<?php 
include_once('includes/header.php');
?>
    
    <div class="content_container">
            
        <form  action="dsiplay.php">
            Реузлати от гласуването за период от
            <input id="datepicker-8" type="text" name="from" style="width: 100px" onfocus="this.blur()" >
            до
            <input id="datepicker-9" type="text" name="to" style="width: 100px" onfocus="this.blur()" >

            <input class="font12" type="submit" value="Покажи">
            
        </form>     
        

    </div>

<?php
include_once('includes/footer.php');
