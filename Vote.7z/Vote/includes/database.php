<?php

ini_set('display_errors', 1);

/**
 * Singleton class used to retrieve one and the same PDO instance
 * with database account configuration for executing queries in the application
 */
class Database {

    /**
     *
     * @var PDO
     */
    private static $instance;

    /**
     * Make constructor private, so nobody can call "new Class".
     */
    private function __construct() {
        
    }

    /**
     * 
     * Call this method to get singleton instance
     * 
     * @param STRING $dsn - constructed later with data from config.php
     * @param STRING $user - with data from config.php
     * @param STRING $pass - with data from config.php
     * @return PDO
     */
    public static function get_connection($dsn, $user, $pass) {

        if (self::$instance === NULL) {
            self::$instance = new PDO($dsn, $user, $pass);
            self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$instance->exec("SET NAMES 'UTF8'");
        }
        return self::$instance;
    }  
    
    /**
     * Make clone magic method private, so nobody can clone instance.
     */
    private function __clone() {
        
    }

    /**
     * Make wakeup magic method private, so nobody can unserialize instance.
     */
    private function __wakeup() {
        
    }

    /**
     * Make sleep magic method private, so nobody can serialize instance.
     */
    private function __sleep() {
        
    }

}
