<!DOCTYPE html>
<html>

    <?php
    include_once('includes/message.php');
    include_once('includes/functions.php');
    

    session_start();

    if (! isset($_SESSION['login_user'])) {
        redirect('login.php', "");
    }
    ?>
    <head>
        <title>Гласуване</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link type="text/css" rel="stylesheet" href="css/jquery-ui.css"> 
        <link type="text/css" rel="stylesheet" href="dark_ui_theme/jquery-ui.structure.min.css"> 
        <link type="text/css" rel="stylesheet" href="dark_ui_theme/jquery-ui.theme.min.css"> 
        
        <link type="text/css" rel="stylesheet" href="css/styles.css">

        <script type='text/javascript' src="js/jquery.min.js"></script>
        <script type='text/javascript'  src="js/jquery-ui.min.js"></script>
        <script type='text/javascript'  src="js/datepicker-bg.js"></script>


        <script>

            $(function () {
                $("#datepicker-8").datepicker({
                    prevText: "Предходни месеци",
                    nextText: "Следваши месеци",
                    showOtherMonths: true,
                    selectOtherMonths: true,
                    dateFormat: "yy-mm-dd",
                    maxDate: "+0m +0w"
                });
                $("#datepicker-9").datepicker({
                    prevText: "Предходни месеци",
                    nextText: "Следваши месеци",
                    showOtherMonths: true,
                    selectOtherMonths: false,
                    dateFormat: "yy-mm-dd",
                    maxDate: "+0m +0w"
                });
            });
            
            $(selector).datepicker($.datepicker.regional[ "bg" ]);
            
        </script>

    </head>

    <body style="margin: 0px;font-family: Verdana">

        <div style="background-color: #00004d;">

            <h5 class="header_left">Войском</h5>
            <h5 class="header_right"><?php echo $_SESSION['login_user']; ?></h5>  

        </div>

        <nav class="sidenav">

            <div class="card">

                <div class="card_title">РЕУЛТАТИ ОТ ГЛАСУВАНЕ</div>

                <a class="font12" href='index.php'> <div class="button">Резултати от гласуване</div> </a>
                <a class="font12"> <div class="button"></div> </a>

            </div>

            <div class="card">

                <div class="card_title">ИЗХОД ОТ СИСТЕМАТА</div>

                <a class="font12" href='logout.php'> <div class="button">Изход от системата</div> </a>
                <a class="font12"> <div class="button"></div> </a>

            </div>

        </nav>


