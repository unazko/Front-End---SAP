<?php

/**
 * 
 * Generates expiring token link, which is used in the content of sent mail
 * 
 * @param INT $page
 * @param STRING $email
 * @param INT $duration
 * @param INT $user_id
 * @return STRING
 */
function generate_token_link($page, $email, $duration, $user_id = NULL) {

    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    $expire_moment = time() + $duration;
    $token = sha1('my-gallery' . $email . $expire_moment);

    if ($user_id == NULL) {
        return 'http://' . $_SERVER['HTTP_HOST'] . $uri . '/' . $page . '?email=' . $email . '&token=' . $token . '&expire=' . $expire_moment;
    } else {
        return 'http://' . $_SERVER['HTTP_HOST'] . $uri . '/' . $page . '?user_id=' . $user_id . '&email=' . $email . '&token=' . $token . '&expire=' . $expire_moment;
    }
}

/**
 * 
 * Redirects to a different page
 * 
 * @param INT $page
 * @param STRING $message
 */
function redirect($page, $message) {

    $host = $_SERVER['HTTP_HOST'];
    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    $location = $host . $uri . '/' . $page . $message;
    header("Location: http://" . $location);
    exit;
}

/**
 * 
 * Reformats user input in order to be inserted into postgreSQL
 * 
 * @param STRING $data
 * @return STRING
 */
function escape_input($data) {

    //$data = trim($data);
    //$data = htmlspecialchars($data);
    pg_escape_string($data);
    return $data;
}

/**
 * 
 * @param STRING $value
 * @param INT $flags
 * @return STRING
 */
function e($value, $flags = ENT_COMPAT) {
    return htmlspecialchars($value, $flags, "UTF-8");
}

/**
 * 
 * This is David Walsh's function 
 * https://davidwalsh.name/create-image-thumbnail-php
 */
function make_thumb($src, $dest, $desired_width) {

    $type = exif_imagetype($src);

    $allowed_types = array(
        1, //-> gif
        2, //-> jpeg
        3 //-> png
    );

    if ( ! in_array($type, $allowed_types)) {
        throw new Exception("The type of the file is not suported");
    }

    switch ($type) {
        case 1:  //gif -> jpg
            $source_image = imagecreatefromgif($src);
            break;
        case 2:  //jpeg -> jpg
            $source_image = imagecreatefromjpeg($src);
            break;
        case 3:  //png -> jpg
            $source_image = imagecreatefrompng($src);
            break;
    }
    /* read the source image */
    $width = imagesx($source_image);
    $height = imagesy($source_image);

    /* find the "desired height" of this thumbnail, relative to the desired width  */
    $desired_height = floor($height * ($desired_width / $width));

    /* create a new, "virtual" image */
    $virtual_image = imagecreatetruecolor($desired_width, $desired_height);

    /* copy source image at a resized size */
    imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);

    /* create the physical thumbnail image to its destination */
    imagejpeg($virtual_image, $dest);
    imagedestroy($virtual_image);
}

/**
 * 
 * @param STRING $class - The name of the class and the name of the file
 * have to be the same for the class file to be autoloaded
 */
function autoload_class($class) {
	include_once('includes/' . $class . '.php');
}
//spl_autoload_register('autoload_class');