<?php

define('host', '127.0.0.1');
define('db', 'vote_app');
define('user', 'postgres');
define('pass', '333123');
define('charset', 'utf8');
define('port', '5432');
define('project_name', 'Vote');
define('time_zone', 'Europe/Sofia');
define('cost', '10');
