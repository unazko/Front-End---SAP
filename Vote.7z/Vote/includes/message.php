<?php

/**
 *      Container for success or failure messages
 */
class Message {

    public $content;
    public $type;

    /**
     * 
     * @param STRING $content
     * @param STRING $type
     */
    function __construct($content, $type) {

        $this->content = $content;
        $this->type = $type;
    }

}