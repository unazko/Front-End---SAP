<?php
ini_set('display_errors', true);
ini_set('log_errors', 1);

include_once("includes/database.php");
include_once("includes/config.php");
include_once("includes/functions.php");


//http://<IP_Address>/<Path>/<script>?id=9937435988709801918191143818756 &msisdn=359887098019&shortcode=1929&op=1&msg=incoming %20message&timestamp=1144841878
    

$date = time();

$page = "receive_request.php";
$host = $_SERVER['HTTP_HOST'];
$request = "?id=7&msisdn=359883095081&shortcode=1929&op=1&msg=slujitel 13&timestamp=$date";

$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$location = $host . $uri . '/' . $page . $request;
header("Location: http://" . $location);
exit;