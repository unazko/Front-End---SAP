<?php
include_once('includes/message.php');
include_once('includes/database.php');
include_once('includes/config.php');
include_once('includes/functions.php');

session_start();

$username = $password = "";
$inner_hash = "";
$user_id = "";

echo "what is the problem<br>";

$flag = FALSE;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST['username'])) {
        
        /**
         *      In order to save inputed data from the login fields
         */
        $_SESSION['username'] = "";
        $flag = TRUE;
    } else {
        $username = escape_input($_POST['username']);
        $_SESSION['username'] = $username;
    }
    if (empty($_POST["password"])) {

        $flag = TRUE;
    } else {
        $password = escape_input($_POST['password']);
    }
}

if ($flag == FALSE) {

    $dsn = "pgsql:host=" . host . ";dbname=" . db . ";port=" . port;
    $pdo = Database::get_connection($dsn, user, pass);

    $stmt = $pdo->prepare("SELECT hash, id FROM users WHERE username = ?");
    $stmt->execute([$username]);

    if ($row = $stmt->fetch()) {

        $inner_hash = $row['hash'];
        $user_id = $row['id'];
    }

    echo $inner_hash;
    
    if(password_verify($password, $inner_hash)) {

        $_SESSION['login_user'] = $username;

        /**
         *      Creating new hash and salt on every login
         * 	Encrypting the password with salt in order to save it in the database
         */
        $new_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => cost]);
        
        $stmt = $pdo->prepare( 'UPDATE users SET hash = ? WHERE id = ?');
        $stmt->bindParam(1, $new_hash);
        $stmt->bindParam(2, $user_id);
        $stmt->execute();
        
        redirect('index.php', "");
        
    } else {

        redirect('login.php',"");
    }
}