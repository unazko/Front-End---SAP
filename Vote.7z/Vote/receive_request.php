<?php

ini_set('display_errors', true);
ini_set('log_errors', 1);

include_once("includes/database.php");
include_once("includes/config.php");
include_once("includes/functions.php");

$ulr_data = array();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $ulr_data['id'] = escape_input($_GET['id']);
}

if (isset($_GET['msisdn']) && !empty($_GET['msisdn'])) {
    $ulr_data['msisdn'] = escape_input($_GET['msisdn']);
}

if (isset($_GET['shortcode']) && !empty($_GET['shortcode'])) {
    $ulr_data['shortcode'] = escape_input($_GET['shortcode']);
}

if (isset($_GET['op']) && !empty($_GET['op'])) {
    $ulr_data['op'] = escape_input($_GET['op']);
}

if (isset($_GET['msg']) && !empty($_GET['msg'])) {
    $ulr_data['msg'] = escape_input($_GET['msg']);
}

if (isset($_GET['timestamp']) && !empty($_GET['timestamp'])) {
    $date = escape_input($_GET['timestamp']);
    $ulr_data['timestamp'] = date('Y-m-d H:i:s', $date);
}


//http://<IP_Address>/<Path>/<script>?id=9937435988709801918191143818756 &msisdn=359887098019&shortcode=1929&op=1&msg=incoming %20message&timestamp=1144841878

$dsn = "pgsql:host=" . host . ";dbname=" . db . ";port=" . port;
$pdo = Database::get_connection($dsn, user, pass);

$sql = "SELECT DIVIDE_VOTES(?::INT, ?::BIGINT, ?::BIGINT, ?::VARCHAR, ?, ?::SMALLINT)";
$stmt = $pdo->prepare($sql);

$stmt->bindParam(1, $ulr_data['id']);
$stmt->bindParam(2, $ulr_data['msisdn']);
$stmt->bindParam(3, $ulr_data['shortcode']);
$stmt->bindParam(4, $ulr_data['msg']);
$stmt->bindParam(5, $ulr_data['timestamp']);
$stmt->bindParam(6, $ulr_data['op']);

$stmt->execute();
echo "Connected to the database successfully.\n";

$response = array();

while ($row = $stmt->fetch()) {

    $response[] = $row['divide_votes'];
}

if ($response[0] == 'FAIL') {

    //http://<<VoiceCom_IP1>>/<<PATH>>/<<script>>? 
    //serviceID=3&id=cd27526e4afd5c6c331ebdd23d4b3f03&shortcode=1929&msisdn=3598870 98019&msg=test%20message&timestamp=1144841878&op=1
} else if ($response[0] == 'SUCCESS') {

    //http://<<VoiceCom_IP1>>/<<PATH>>/<<script>>? 
    //serviceID=3&id=cd27526e4afd5c6c331ebdd23d4b3f03&shortcode=1929&msisdn=3598870 98019&msg=test%20message&timestamp=1144841878&op=1
}


var_dump($ulr_data);

